# 🚗 Weltfahrspiel

Ein Open-World-Fahrspiel im Browser: Du fährst durch **echte Städte der ganzen Welt**.
Straßen und Gebäude kommen live aus [OpenStreetMap](https://www.openstreetmap.org/). Gesucht wird ein beliebiger Ort, das Spiel lädt die Karte kachelweise um dich herum.

> **Status:** frühe Version (Prototyp). Läuft komplett im Browser, ohne Build-Schritt und ohne Server.

## Dateien

| Datei | Inhalt |
|---|---|
| `index.html` | **Hauptspiel** mit der OSM-Weltkarte (Overpass + Nominatim) |
| `demo.html` | Offline-Demo mit erfundener Stadt: Ampeln, Fußgänger, Polizei, Minikarte, Flugzeuge und Flughäfen (Einzelspieler) |

## Spielen

**Online (GitHub Pages):** Repository auf GitHub hochladen → *Settings → Pages → Source: GitHub Actions*. Nach dem ersten Push auf `main` läuft der Workflow in `.github/workflows/pages.yml`, danach ist das Spiel unter `https://<dein-name>.github.io/<repo-name>/` erreichbar (auch auf dem iPad).

**Lokal:**

```bash
python3 -m http.server 8000
# dann http://localhost:8000 öffnen
```

Eine lokale Auslieferung ist nötig, weil der Browser Karten-Anfragen sonst teils blockiert.

## Steuerung

| Aktion | Tastatur | Touch |
|---|---|---|
| Gas / Bremse | W / S oder ↑ / ↓ | W / S |
| Lenken | A / D oder ← / → | ◀ ▶ |
| Handbremse | Leertaste | ■ |
| Zurück auf die Straße | R | – |

Oben gibst du einen Ort ein („Tokio Shibuya“, „Hauptstraße 1, Erfurt“ …) oder drückst **🎲 Zufallsort**.

## So funktioniert es

- **Geocoding:** [Nominatim](https://nominatim.org/) wandelt den Suchtext in Koordinaten um.
- **Kartendaten:** [Overpass API](https://overpass-api.de/) liefert pro Kachel (0,01° ≈ 1 km) Straßen (`highway=*`) und Gebäude (`building=*`).
- **Straßen:** Linien werden zu Bändern mit Breite je nach Straßentyp. Auf der Straße hast du Grip, daneben rutschst du.
- **Gebäude:** Grundrisse werden mit Höhe (`height`, `building:levels`) extrudiert und sind feste Hindernisse.
- **Verkehr:** Bot-Autos fahren auf dem Straßengraphen, rechts, und biegen an Kreuzungen zufällig ab.
- **Rendering:** [three.js](https://threejs.org/) (r128 über CDN).

## Roadmap

- [ ] Flugzeuge und echte Flughäfen aus OSM (`aeroway=*`)
- [ ] Fußgänger, Ampeln (`highway=traffic_signals`), Polizei
- [ ] Grünflächen, Wasser, Fahrbahnmarkierungen
- [ ] Mehrspieler (z. B. über WebRTC oder einen kleinen Relay-Server)
- [ ] Offline-Cache der Kacheln (IndexedDB)
- [ ] Bessere Grafik (Schatten, Texturen, Himmel)

## Hinweise zur Nutzung der Dienste

- Die öffentlichen Overpass- und Nominatim-Server sind für gelegentliche Nutzung gedacht. Für viele Spieler bitte eigene Instanzen betreiben oder einen Anbieter nutzen. Beachte die [Nominatim Usage Policy](https://operations.osmfoundation.org/policies/nominatim/).
- Karten- und Gebäudedaten: **© OpenStreetMap-Mitwirkende**, lizenziert unter der [ODbL](https://www.openstreetmap.org/copyright). Die Namensnennung ist im Spiel unten rechts eingeblendet und muss erhalten bleiben.

## Lizenz

Code: [MIT](LICENSE). Kartendaten: ODbL (siehe oben).
